package sdklogindemo.example.com.apklib;

/**
 * Created by suweiguang on 2016/4/6.
 */
public class LibTest {

  public   static String main(){
        return "";
    }
}
