package com.vector.update_app.listener;

/**
 * Created by Vector
 * on 2018/4/9.
 */
public interface ExceptionHandler {
     void onException(Exception e);
}
