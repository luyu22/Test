package com.hairuyi.www.wxapi;


import com.umeng.socialize.weixin.view.WXCallbackActivity;

/**
 * Created by ntop on 15/9/4. 微信回调接口
 */
public class WXEntryActivity extends WXCallbackActivity {

}
