package com.oubowu.stickyitemdecoration;

public interface OnStickyChangeListener{
        void onScrollable(int offset);
        void onInVisible();
    }