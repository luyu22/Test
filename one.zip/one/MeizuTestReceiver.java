package com.hairuyi.www;

import org.android.agoo.mezu.MeizuPushReceiver;

public class MeizuTestReceiver extends MeizuPushReceiver {
}
